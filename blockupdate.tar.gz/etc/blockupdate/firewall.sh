#!/bin/sh
# Copyright (C) 2016 evenS

start(){
    iptables -t filter -N disable_update
	iptables -t filter -I FORWARD -j disable_update
    for domain in $(cat /etc/blockupdate/domainlist | awk  '{print $1}'); do
        iptables -t filter -I disable_update -m string --string $domain --algo kmp -j DROP
    done 
}

stop(){
	iptables -t filter -F disable_update
	iptables -t filter -D FORWARD -j disable_update
	iptables -t filter -X disable_update
}

case "$1" in
    "start")
        start
        exit 0;
        ;;
    "stop")
        stop
        exit 0;
        ;;                
esac  